# Basic Student Information Page

This is a simple HTML/CSS project for GitHub.

## Student Details
- **Name:** JOHNEDELLE M DEVERA
- **Course:** BSIT
- **Section:** SM 4101
- **Subject:** PLATFORM TECHNOLOGIES

## How to Use
1. Upload all files to a GitHub repository.
2. Open `index.html` in your browser.
